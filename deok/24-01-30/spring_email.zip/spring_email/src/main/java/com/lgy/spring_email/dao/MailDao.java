package com.lgy.spring_email.dao;

import java.util.Map;

import com.lgy.spring_email.dto.MailDto;

public interface MailDao {

	public MailDto getmail(String id);
}
