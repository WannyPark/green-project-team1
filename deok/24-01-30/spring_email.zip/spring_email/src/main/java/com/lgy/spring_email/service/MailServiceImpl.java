package com.lgy.spring_email.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_email.dao.MailDao;
import com.lgy.spring_email.dto.MailDto;

@Service
public class MailServiceImpl implements MailService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public int getmail(String id, String name, String email) {
		int res = 0;
//		
//		System.out.println(id);
//		System.out.println(name);
//		System.out.println(email);
		
		MailDao dao = sqlSession.getMapper(MailDao.class);
//		HashMap<String, String> map = (HashMap<String, String>)dao.getmail(id);
		MailDto dto = dao.getmail(id);
//		System.out.println(map);
		
		
		if (dto.getID().isEmpty()) {
			res= 0;
		}else if (!dto.getID().equals(id) || !dto.getNAME().equals(name) || !dto.getEMAIL().equals(email)) {
			res= 0;
		}else {
			res=1;
		}
		
//		if (map.isEmpty()) {
//			res = 0;
//		} else if (!map.get("name").equals(name) || !map.get("email").equals(email)) {
//			res = 0;
//		} else {
//			res = 1;
//		}
		
		return res;
	}

}
