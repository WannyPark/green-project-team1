package com.lgy.spring_react_board_list_details.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lgy.spring_react_board_list_details.dto.ListDto;
import com.lgy.spring_react_board_list_details.service.ListService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ListController {
	
	@Autowired
	private ListService listService;
	
	// 게시판 목록 조회
	@RequestMapping(value="/api/reqMem", method = RequestMethod.POST)
//	@PostMapping(value="/api/reqMem")
//	public String list(Model model) {
//	public Model list(Model model) {
	public ResponseEntity<List<ListDto>> saveData(@RequestBody HashMap<String, String> map) {
		log.info("@# content_view start");
		String id = map.get("id");
		System.out.println(id);
//		ArrayList<ListDto> res = listService.contentView();
//		ArrayList<ListDto> res = new ArrayList<ListDto>();
		ArrayList<ListDto> res = listService.contentView(id);
		
		return new ResponseEntity<List<ListDto>>(res, HttpStatus.OK);
	}
	
//	@RequestMapping("/modify")
	@RequestMapping(value="/api/updateMem", method = RequestMethod.POST)
//	public void modify(@RequestParam HashMap<String, String> param) {
//	public void modify(@RequestBody HashMap<String, String> param) {
	public ResponseEntity<String> modify(@RequestBody HashMap<String, String> param) {
		log.info("@# modify start");
//		ibDao.modify(request.getParameter("bid")
//				 , request.getParameter("bname")
//				 , request.getParameter("btitle")
//				 , request.getParameter("bcontent"));
//		bService.modify(param);
		listService.modify(param);
		return null;	
		
//		return "redirect:list";
//		return listService.modify(param);
//		return new ResponseEntity<List<ListDto>>(res, HttpStatus.OK);
	}
	
//	@RequestMapping("/delete")
	@RequestMapping(value="/api/deleteMem", method = RequestMethod.DELETE)
//	public void delete(@RequestParam HashMap<String, String> param) {
//	public void delete(@RequestBody HashMap<String, String> param) {
	public ResponseEntity<String> delete(@RequestBody HashMap<String, String> param) {
		log.info("@# delete start");
//		ibDao.delete(request.getParameter("bid"));
//		bService.delete(param);
		listService.delete(param);
		return null;
		
//		return "redirect:list";
	}
}
