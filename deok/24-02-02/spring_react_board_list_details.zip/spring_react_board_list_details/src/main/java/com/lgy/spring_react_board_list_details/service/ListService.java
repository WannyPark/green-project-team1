package com.lgy.spring_react_board_list_details.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;

import com.lgy.spring_react_board_list_details.dto.ListDto;

public interface ListService {
	public ArrayList<ListDto> contentView(String id);
	public void modify(HashMap<String, String> param);
	public void delete(HashMap<String, String> param);
}
