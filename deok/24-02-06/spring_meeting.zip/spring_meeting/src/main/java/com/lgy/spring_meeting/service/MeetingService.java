package com.lgy.spring_meeting.service;

import java.util.HashMap;

import com.lgy.spring_meeting.dto.MeetingDto;

public interface MeetingService {
	public MeetingDto getid(String id);
	public void makemeeting(HashMap<String, String> param);
}
