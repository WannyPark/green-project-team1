package com.lgy.spring_meeting.dao;

import java.util.HashMap;

import com.lgy.spring_meeting.dto.MeetingDto;

public interface MeetingDao {
	public MeetingDto getid(String title);
	public void makemeeting(HashMap<String, String> param);
}
