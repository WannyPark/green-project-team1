package com.lgy.spring_meeting.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lgy.spring_meeting.service.MeetingService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class MeetingController {

	@Autowired
	private MeetingService meetingService;
	
	@RequestMapping(value = "/api/makeMeeting", method = RequestMethod.POST)
	public String makeMeeting(@RequestBody HashMap<String, String> param) {
		log.info("!@!@! make st");
		
		meetingService.makemeeting(param);
		log.info("!@!@! make ed");
		
		return null; 
		
	}
}
