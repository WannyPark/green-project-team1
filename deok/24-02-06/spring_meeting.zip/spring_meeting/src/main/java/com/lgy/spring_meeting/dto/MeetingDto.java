package com.lgy.spring_meeting.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeetingDto {
	
	private String id;
	private String title;
	private String area;	
	private String area2;	
	private String content;
	private String img_name;
	private String img_name2;
	
	
}
