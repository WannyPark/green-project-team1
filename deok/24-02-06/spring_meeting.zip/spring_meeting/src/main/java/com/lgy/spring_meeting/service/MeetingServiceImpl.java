package com.lgy.spring_meeting.service;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_meeting.dao.MeetingDao;
import com.lgy.spring_meeting.dto.MeetingDto;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MeetingServiceImpl implements MeetingService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public MeetingDto getid(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void makemeeting(HashMap<String, String> param) {
		log.info("!@!@ make start !!");
		
		MeetingDao dao = sqlSession.getMapper(MeetingDao.class);
		dao.makemeeting(param);
		log.info("!@!@ make end !!");
	}

}
