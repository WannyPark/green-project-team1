package com.lgy.spring_home.dao;

import java.util.ArrayList;

import com.lgy.spring_home.dto.HDto;

public interface HDao {
	public ArrayList<HDto> getH(String title);
}
