package com.lgy.spring_home.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgy.spring_home.dto.HDto;
import com.lgy.spring_home.service.HService;

@Controller
public class HController {
	
	@Autowired
	private HService service;
	
	@ResponseBody
	@RequestMapping(value="/home")
	public ResponseEntity<ArrayList<HDto>> home(HttpServletRequest request) {
		ArrayList<HDto> dto = null;
		String title = request.getParameter("title");
		System.out.println("@#@#@# title ===> " + title);
		dto = service.getH(title);
		System.out.println("@# dto ===> " + dto);
		
		return new ResponseEntity<ArrayList<HDto>>(dto,HttpStatus.OK);
	}

}
