package com.lgy.spring_home.service;

import java.util.ArrayList;

import com.lgy.spring_home.dto.HDto;

public interface HService {
	public ArrayList<HDto> getH(String title);

}
