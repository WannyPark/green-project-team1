package com.lgy.spring_home.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_home.dao.HDao;
import com.lgy.spring_home.dto.HDto;

@Service

public class HServiceImpl implements HService {
	
	@Autowired
	private SqlSession sqlsession;

	@Override
	public ArrayList<HDto> getH(String title){
		
		HDao dao = sqlsession.getMapper(HDao.class);
		ArrayList<HDto> dto = dao.getH(title);
		
		return dto;
	}

}
