package com.lgy.spring_email.service;

public interface MailService {
	
	public int getmail(String id, String name, String email);
}
