package com.lgy.spring_email.dao;

import java.util.Map;

public interface MailDao {

	public Map<String, String> getmail(String id);
}
