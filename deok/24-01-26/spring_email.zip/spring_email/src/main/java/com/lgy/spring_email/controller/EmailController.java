//package com.lgy.spring_email.controller;
//
//import java.util.Map;
//import java.util.Random;
//
//import javax.servlet.http.HttpServletRequest;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//@Controller
//public class EmailController {
//
//    @Autowired
//    private JavaMailSender mailSender;
//
//    @ResponseBody
//    @RequestMapping(value="/api/email")
//    public String find_post(@RequestParam Map<String, Object> map, HttpServletRequest req) throws Exception {
//        // 랜덤한 숫자문자를 합친 문자열을 전달받은 map의 email로 보낸다.
//        Random rand = new Random();
//        String strRand = "";
//        for (int i = 0; i < 4; i++) {
//            strRand += rand.nextInt(10);
//        }
//
//        MailUtils sendMail = new MailUtils(mailSender);
//        sendMail.setSubject("회원가입 이메일 인증");
//        String message = new StringBuffer()
//                .append("<h1>[이메일 인증]발신전용이므로 회신 불가</h1>")
//                .append("<p>인증번호: ")
//                .append(strRand)
//                .append("</p>")
//                .toString();
//
//        sendMail.setText(message);
//        sendMail.setFrom("vgb2145345@naver.com", "관리자");
//        sendMail.setTo("rudehd5@naver.com");
//        sendMail.send();
//
//        // 의미 있는 응답을 반환하도록 변경 (테스트 목적이라면 현재 상태로도 괜찮습니다.)
//        return "Email sent successfully";
//    }
//}


package com.lgy.spring_email.controller;

import java.util.Map;
import java.util.Random;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgy.spring_email.dto.MailDto;
import com.lgy.spring_email.service.MailService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class EmailController {

    @Autowired
    private JavaMailSender mailSender;
    
    @Autowired
    private MailService service;

    @ResponseBody
    @RequestMapping(value = "/api/email")
//    public String sendEmail(@RequestParam Map<String, Object> map) {
   	public int sendEmail(HttpServletRequest request) {
    	int res = 0;
    	String id = request.getParameter("id");
    	String name = request.getParameter("name");
    	String email = request.getParameter("email");
    	System.out.println(id);
    	System.out.println(name);
    	System.out.println(email);
    	res = service.getmail(id, name, email);
    	
    	if (res == 0) {
    		return 0;
    	}
    	
        // 랜덤한 숫자문자를 합친 문자열을 전달받은 map의 email로 보낸다.
        Random rand = new Random();
        String strRand = "";
        for (int i = 0; i < 4; i++) {
            strRand += rand.nextInt(10);
        }

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            messageHelper.setSubject("회원가입 이메일 인증");
            String message = new StringBuffer()
                    .append("<h1>[이메일 인증]발신전용이므로 회신 불가</h1>")
                    .append("<p>인증번호: ")
                    .append(strRand)
                    .append("</p>")
                    .toString();
            messageHelper.setText(message, true);
            messageHelper.setFrom("vgb2145345@gmail.com", "관리자");
            messageHelper.setTo(email);

            mailSender.send(mimeMessage);
            return res;
//            return "Email sent successfully";
        } catch (Exception e) {
//            return "Error sending email: " + e.getMessage();
        	return 0;
        }
    }
}
