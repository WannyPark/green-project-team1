import { useEffect, useState } from 'react';
import "aos/dist/aos.css";
import Navi from './Navi';
import '../css/home.css';
import '../css/board.css';
import axios from 'axios';

//보드 리스트
function App() {
    const [list,setList]  = useState([]);
    const getList = async () =>{
        const res = await (await axios.get("/boardCheck")).data;
        setList(res);
      console.log(res);  
      }
     useEffect(() =>{
      getList();
     },[])

    return (
        <div className="view_mem">
            <Navi />
            
            <table className='tablehead'>
                <div className='tablebody'>
                    <thead>
                        <tr>
                            <th className='boardNum'>글번호</th>
                            <th className='boardTitle'>글제목 </th>
                            <th className='boardWriter'>작성자</th>
                            <th className='boardDate'>작성일 </th>
                            <th className='boardHit'>조회수 </th>
                        </tr>
                    </thead>
                    <tbody>
                    {list.map((item) => (
                        <tr key={item.boardNum} className='list'>
                            <td>{item.boardNum}</td>
                            <td>{item.boardTitle}</td>
                            <td>{item.boardWriter}</td>
                            <td>{item.boardDate}</td>
                            <td>{item.boardHit}</td>
                         </tr>
                    ))}
                    </tbody>
                </div>
            </table>
                 </div>

            

);
}

export default App;
