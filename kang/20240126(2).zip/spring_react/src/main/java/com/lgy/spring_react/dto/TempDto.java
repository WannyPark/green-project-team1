package com.lgy.spring_react.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TempDto {
	private String 	id;
	private String	EMAIL;
	private String	NAME;
	private String	BIRTH;
	private String	ADDR;
	private String	ADDR2;

	
	
}
