package com.lgy.project_server.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgy.project_server.dto.GatDto;
import com.lgy.project_server.service.GatService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class GatController {

	@Autowired
	private GatService gatService;
	
	@ResponseBody
	@RequestMapping(value="/api/getGat")
	public ResponseEntity<ArrayList<GatDto>> getGat(HttpServletRequest request) {
		ArrayList<GatDto> list = null;
		
		String search = request.getParameter("search");
		System.out.println(search);
		list = gatService.getGat(search);
		
		return new ResponseEntity<ArrayList<GatDto>>(list, HttpStatus.OK);
	}
	
}
