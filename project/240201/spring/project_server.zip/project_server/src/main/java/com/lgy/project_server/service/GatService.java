package com.lgy.project_server.service;

import java.util.ArrayList;

import com.lgy.project_server.dto.GatDto;

public interface GatService {

	public ArrayList<GatDto> getGat(String search);
	
}
