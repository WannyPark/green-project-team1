package com.lgy.project_server.service;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.project_server.dao.GatDao;
import com.lgy.project_server.dto.GatDto;

@Service("GatService")
public class GatServiceImpl implements GatService {

	@Autowired
	private SqlSession sqlSession;
	
	public ArrayList<GatDto> getGat(String search) {
		GatDao dao = sqlSession.getMapper(GatDao.class);
		ArrayList<GatDto> list = dao.getGat(search);
		System.out.println(list);
		
		return list;
	}
	
}
