package com.lgy.project_server.service;

public interface LoginService {

	public int login_check(String id, String pw);
	
}
