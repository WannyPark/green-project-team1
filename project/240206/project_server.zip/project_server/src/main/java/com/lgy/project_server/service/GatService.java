package com.lgy.project_server.service;

import java.util.ArrayList;

import com.lgy.project_server.dto.GatDto;

public interface GatService {

	public ArrayList<GatDto> getGat(String search);
	
	public ArrayList<GatDto> searchAll();
	
	public int getTotalPage();
	
	public ArrayList<GatDto> getMemGat(String id);
	
	public ArrayList<GatDto> locationGats(String location1, String location2);
	
	public int makeGat(String mem_id, String mem_nName, String title, String desc, String location1, String location2
			, String file1, String file2, String fileExt, long fileSize);
	
	public int makeGatNoFile(String mem_id, String mem_nName, String title, String desc, String location1, String location2);
	
}
