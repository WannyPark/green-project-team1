package com.lgy.project_server.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Param;

import com.lgy.project_server.dto.GatDto;

public interface GatDao {

	public ArrayList<GatDto> getGat(@Param("search") String search);
	
}
