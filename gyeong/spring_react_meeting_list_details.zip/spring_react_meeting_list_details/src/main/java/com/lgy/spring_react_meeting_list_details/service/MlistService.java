package com.lgy.spring_react_meeting_list_details.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;

import com.lgy.spring_react_meeting_list_details.dto.MlistDto;

public interface MlistService {
	public ArrayList<MlistDto> contentView(String id);
	public void modify(HashMap<String, String> param);
	public void delete(HashMap<String, String> param);
	public void addComment(String id, String comments, Timestamp date);
	public void joinMeeting(String id);
}
