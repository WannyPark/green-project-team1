package com.lgy.spring_react_meeting_list_details.dto;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MlistDto {
	private String id;
	private Timestamp date;
	private String title;
	private String content;
	private String comments;
	private String schedule;
	private String member;
}
