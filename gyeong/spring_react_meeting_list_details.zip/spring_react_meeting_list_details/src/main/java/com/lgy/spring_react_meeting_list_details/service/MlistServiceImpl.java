package com.lgy.spring_react_meeting_list_details.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_react_meeting_list_details.dao.*;
import com.lgy.spring_react_meeting_list_details.dto.MlistDto;

import lombok.extern.slf4j.Slf4j;

@Service("MlistSevice")
@Slf4j
public class MlistServiceImpl implements MlistService{

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public ArrayList<MlistDto> contentView(String id) {
		log.info("@# MlistServiceImpl.contentView() start");
		
		MlistDao mlistDao = sqlSession.getMapper(MlistDao.class);
//		ArrayList<ListDto> dtos = listDao.contentView();
		ArrayList<MlistDto> dtos = mlistDao.contentView(id);
		System.out.println(dtos);
		
		log.info("@# MlistServiceImpl.contentView() end");
		
		return dtos;
	}

	@Override
	public void modify(HashMap<String, String> param) {
			log.info("@# MlistServiceImpl.modify() start");
			
			MlistDao mlistDao = sqlSession.getMapper(MlistDao.class);
			mlistDao.modify(param);
			
			log.info("@# MlistServiceImpl.modify() end");
		}

	@Override
	public void delete(HashMap<String, String> param) {
		log.info("@# MlistServiceImpl.delete() start");
		
		MlistDao mlistDao = sqlSession.getMapper(MlistDao.class);
		mlistDao.delete(param);
		
		log.info("@# MlistServiceImpl.delete() end");
	}

	@Override
	public void addComment(String id, String comments, Timestamp date) {
		log.info("@# MlistServiceImpl.addComment() start");
		
		MlistDao mlistDao = sqlSession.getMapper(MlistDao.class);
		mlistDao.addComment(id, comments, date);
		
		log.info("@# MlistServiceImpl.addComment() end");
	}

	@Override
	public void joinMeeting(String id) {
		log.info("@# MlistServiceImpl.joinMeeting() start");
		
		MlistDao mlistDao = sqlSession.getMapper(MlistDao.class);
		mlistDao.joinMeeting(id);
		
		log.info("@# MlistServiceImpl.joinMeeting() end");
	}

}