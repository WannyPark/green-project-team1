package com.lgy.spring_react_meeting_list_details.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;

import com.lgy.spring_react_meeting_list_details.dto.*;

public interface MlistDao {
	public ArrayList<MlistDto> contentView(@Param("id") String id);
	public void modify(HashMap<String, String> param);
	public void delete(HashMap<String, String> param);
	public void addComment(@Param("id") String id, @Param("comments") String comments, @Param("date") Timestamp date);
	public void joinMeeting(@Param("id") String id);
}
