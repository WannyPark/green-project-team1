package com.lgy.spring_react_meeting_list_details.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lgy.spring_react_meeting_list_details.dto.MlistDto;
import com.lgy.spring_react_meeting_list_details.service.MlistService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class MlistController {
	
	@Autowired
	private MlistService mlistService;
	
	// 게시판 목록 조회
	@RequestMapping(value="/api/reqMem", method = RequestMethod.POST)
	public ResponseEntity<List<MlistDto>> saveData(@RequestBody HashMap<String, String> map) {
		log.info("@# content_view start");
		String id = map.get("id");
		System.out.println(id);
//		ArrayList<ListDto> res = new ArrayList<ListDto>();
		ArrayList<MlistDto> res = mlistService.contentView(id);
		
		return new ResponseEntity<List<MlistDto>>(res, HttpStatus.OK);
	}
	
	@RequestMapping(value="/api/updateMem", method = RequestMethod.POST)
	public ResponseEntity<String> modify(@RequestBody HashMap<String, String> param) {
		log.info("@# modify start");
		
		mlistService.modify(param);
		
		return null;
	}
	
	@RequestMapping(value="/api/deleteMem", method = RequestMethod.DELETE)
	public ResponseEntity<String> delete(@RequestBody HashMap<String, String> param) {
		log.info("@# delete start");
		
		mlistService.delete(param);
		
		return null;
	}
	
	@RequestMapping(value = "/api/addComment", method = RequestMethod.POST)
//	public ResponseEntity<String> addComment(@RequestBody HashMap<String, String> param) {
	public ResponseEntity<String> addComment(@RequestBody MlistDto param) {
		log.info("@# addComment start");

//		String id = param.get("id");
//		String comment = param.get("comment");
//		Timestamp date = Timestamp.valueOf(param.get("date"));
		String id = param.getId();
        String comment = param.getComments();
        Timestamp date = param.getDate();
		
		mlistService.addComment(id, comment, date);
		return null;
		
	}
	
	@RequestMapping(value = "/api/joinMeeting", method = RequestMethod.POST)
//	public ResponseEntity<String> addComment(@RequestBody HashMap<String, String> param) {
	public ResponseEntity<String> joinMeeting(@RequestBody MlistDto param) {
		log.info("@# addComment start");
		
		String id = param.getId();
		
		mlistService.joinMeeting(id);
		return null;
		
	}
}
