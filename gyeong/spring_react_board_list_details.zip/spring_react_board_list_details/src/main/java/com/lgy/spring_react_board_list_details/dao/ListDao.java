package com.lgy.spring_react_board_list_details.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;

import com.lgy.spring_react_board_list_details.dto.ListDto;

public interface ListDao {
	public ArrayList<ListDto> contentView(@Param("id") String id);
	public void modify(HashMap<String, String> param);
	public void delete(HashMap<String, String> param);
}
