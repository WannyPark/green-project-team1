package com.lgy.spring_react_board_list_details.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_react_board_list_details.dto.ListDto;
import com.lgy.spring_react_board_list_details.dao.*;

import lombok.extern.slf4j.Slf4j;

@Service("ListService")
@Slf4j
public class ListServiceImpl implements ListService{

	@Autowired
	private SqlSession sqlSession;
	
	@Override
//	public ArrayList<ListDto> contentView() {
	public ArrayList<ListDto> contentView(String id) {
		log.info("@# ListServiceImpl.contentView() start");
		
		ListDao listDao = sqlSession.getMapper(ListDao.class);
//		ArrayList<ListDto> dtos = listDao.contentView();
		ArrayList<ListDto> dtos = listDao.contentView(id);
		System.out.println(dtos);
		
		log.info("@# ListServiceImpl.contentView() end");
		
		return dtos;
	}

	@Override
	public void modify(HashMap<String, String> param) {
//	public ArrayList<ListDto> modify(HashMap<String, String> param) {
		log.info("@# ListServiceImpl.modify() start");
		
		ListDao listDao = sqlSession.getMapper(ListDao.class);
//		ibDao.modify(request.getParameter("bid")
//				 , request.getParameter("bname")
//				 , request.getParameter("btitle")
//				 , request.getParameter("bcontent"));
//		ibDao.modify(param);
		
		listDao.modify(param);
		
		log.info("@# ListServiceImpl.modify() end");
	}

	@Override
	public void delete(HashMap<String, String> param) {
		log.info("@# ListServiceImpl.delete() start");
		
		ListDao listDao = sqlSession.getMapper(ListDao.class);
//		ibDao.delete(request.getParameter("bid"));
//		ibDao.delete(param);
		listDao.delete(param);
		
		log.info("@# ListServiceImpl.delete() end");
	}
}
