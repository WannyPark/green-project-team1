package com.lgy.spring_react_server.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.lgy.spring_react_server.dto.*;

public interface TempDao {
	public int getMem(TempDto dto);
//	public String login(TempDto loginDto);
//	public ArrayList<TempDto> login(HashMap<String, String> param);	
}
