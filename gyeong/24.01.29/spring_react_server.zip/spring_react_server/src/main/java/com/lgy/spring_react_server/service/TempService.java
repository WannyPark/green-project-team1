package com.lgy.spring_react_server.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.lgy.spring_react_server.dto.*;

public interface TempService {
	public int getMem(TempDto dto);
//	public String login(TempDto loginDto);
//	public ArrayList<TempDto> login(HashMap<String, String> param);
	
}
