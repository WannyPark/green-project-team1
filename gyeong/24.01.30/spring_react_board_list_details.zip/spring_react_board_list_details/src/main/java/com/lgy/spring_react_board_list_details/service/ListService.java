package com.lgy.spring_react_board_list_details.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.lgy.spring_react_board_list_details.dto.ListDto;

public interface ListService {
//	public int getList(ListDto dto);
//	public ListDto getList(HashMap<String, String> param);
//	public ArrayList<ListDto> contentView();
	public ArrayList<ListDto> contentView(String id);
}
