package com.lgy.spring_react_board_list_details.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Param;

import com.lgy.spring_react_board_list_details.dto.ListDto;

public interface ListDao {
//	public int getList(ListDto dto);
//	public ListDto getList(HashMap<String, String> param);
//	public ArrayList<ListDto> contentView();
	public ArrayList<ListDto> contentView(@Param("id") String id);
}
