package com.lgy.spring_react_board_list_details.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgy.spring_react_board_list_details.dto.ListDto;
import com.lgy.spring_react_board_list_details.service.ListService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ListController {
	
	@Autowired
	private ListService listService;
	
//	@ResponseBody
//	@RequestMapping(value = "/api/reqMem", method = RequestMethod.POST)
//	public int details(@RequestBody ListDto dto) {
//		log.info("@# details start");
//		
//		String id = dto.getId();
//		String date = dto.getDate();
//		String hit = dto.getHit();
//		String title = dto.getTitle();
//		String content = dto.getContent();
//		
//		ListDto tdto = new ListDto(id, date, hit, title, content);
//		
//		int res = listService.getList(tdto);
//		
//		log.info("@# details end");
//		
//		return res;
//	}
	
//	@ResponseBody
//	@RequestMapping(value="/api/reqMem", method = RequestMethod.POST)
//	public ListDto getList(@RequestParam HashMap<String, String> param, Model model) {
//		log.info("@# getList start");
//		
//		ListDto dto = listService.getList(param);
////		model.addAttribute("getList", dto);
//		
//		log.info("@# getList end");
//		
//		return dto;
//	}
	
	// 게시판 목록 조회
	@RequestMapping(value="/api/reqMem", method = RequestMethod.POST)
//	@PostMapping(value="/api/reqMem")
//	public String list(Model model) {
//	public Model list(Model model) {
	public ResponseEntity<List<ListDto>> saveData(@RequestBody HashMap<String, String> map) {
		log.info("@# content_view start");
		String id = map.get("id");
		System.out.println(id);
//		ArrayList<ListDto> res = listService.contentView();
//		ArrayList<ListDto> res = new ArrayList<ListDto>();
		ArrayList<ListDto> res = listService.contentView(id);
		
		return new ResponseEntity<List<ListDto>>(res, HttpStatus.OK);
	}
}
