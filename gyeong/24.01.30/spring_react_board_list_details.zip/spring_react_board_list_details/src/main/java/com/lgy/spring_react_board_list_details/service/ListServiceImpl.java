package com.lgy.spring_react_board_list_details.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_react_board_list_details.dto.ListDto;
import com.lgy.spring_react_board_list_details.dao.*;

import lombok.extern.slf4j.Slf4j;

@Service("ListService")
@Slf4j
public class ListServiceImpl implements ListService{

	@Autowired
	private SqlSession sqlSession;

//	@Override
//	public int getList(ListDto dto) {
//		log.info("@# ListServiceImpl.getList() start");
//		
//		ListDao dao = sqlSession.getMapper(ListDao.class);
//		int res = dao.getList(dto);
//		
//		log.info("@# ListServiceImpl.getList() end");
//		
//		return res;
//	}
	
//	@Override
//	public ListDto getList(HashMap<String, String> param) {
//		log.info("@# ListServiceImpl.getList() start");
//		
//		ListDao dao = sqlSession.getMapper(ListDao.class);
//		ListDto dto = dao.getList(param);
//		
//		log.info("@# ListServiceImpl.getList() end");
//		
//		return dto;
//	}
	
	@Override
//	public ArrayList<ListDto> contentView() {
	public ArrayList<ListDto> contentView(String id) {
		log.info("@# ListServiceImpl.contentView() start");
		
		ListDao listDao = sqlSession.getMapper(ListDao.class);
//		ArrayList<ListDto> dtos = listDao.contentView();
		ArrayList<ListDto> dtos = listDao.contentView(id);
		System.out.println(dtos);
		
		log.info("@# ListServiceImpl.contentView() end");
		
		return dtos;
	}
}
