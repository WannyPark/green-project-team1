package com.lgy.spring_react_server.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.spring_react_server.dao.*;
import com.lgy.spring_react_server.dto.*;

import lombok.extern.slf4j.Slf4j;

@Service("TempService")
@Slf4j
public class TempServiceImpl implements TempService {
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public int getMem(TempDto dto) {
		log.info("@# TempServiceImpl.getMem() start");
		
		TempDao dao = sqlSession.getMapper(TempDao.class);
		int res = dao.getMem(dto);
		
		log.info("@# TempServiceImpl.getMem() end");
		
		return res;
	}

//	@Override
//	public String login(TempDto loginDto) {
//		log.info("@# TempServiceImpl.login() start");
//		
//		TempDao dao = sqlSession.getMapper(TempDao.class);
//		String res = dao.login(loginDto);
//		
//		log.info("@# TempServiceImpl.login() end");
//		return res;
//	}
//	
//	@Override
//	public ArrayList<TempDto> login(HashMap<String, String> param) {
//		log.info("@# TempServiceImpl.login() start");
//		
//		TempDao dao = sqlSession.getMapper(TempDao.class);
//		ArrayList<TempDto> dtos = dao.login(param);
//		
//		log.info("@# TempServiceImpl.login() end");
//		return null;
//	}

}
