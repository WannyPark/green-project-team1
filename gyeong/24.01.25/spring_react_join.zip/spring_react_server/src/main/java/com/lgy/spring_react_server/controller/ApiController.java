package com.lgy.spring_react_server.controller;


import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgy.spring_react_server.dto.*;
import com.lgy.spring_react_server.service.*;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ApiController {

	@Autowired
	private TempService service;
	
	@ResponseBody
	@RequestMapping(value="/api/reqMem")
//	public ResponseEntity<TempDto> api3(HttpServletRequest request) {
	public int api3(HttpServletRequest request) {
		log.info("@# api3 start");
		String uid = request.getParameter("uid");
		String pwd = request.getParameter("pwd");
		String email = request.getParameter("email");
		String name = request.getParameter("name");
		String birthday = request.getParameter("birthday");
		String address1 = request.getParameter("address1");
		String address2 = request.getParameter("address2");
		
		TempDto dto = new TempDto(uid, pwd, email, name, birthday, address1, address2);
		
		int res = service.getMem(dto);
		log.info("@# api3 end");
		
//		return new ResponseEntity<Integer>(res,HttpStatus.OK);
		return res;
	}
	
//	@ResponseBody
//	@RequestMapping(value="/api/reqMem")
////	public String login(@RequestParam HashMap<String, String> param) {
//	public String login(HttpServletRequest request) {
//		log.info("@# login start");
//		
//		String uid = request.getParameter("uid");
//		String pwd = request.getParameter("pwd");
//		
//		TempDto loginDto = 
//		
//		if (dtos.isEmpty()) {
//			return res=1;
//		} else {
//			if (param.get("mem_pwd").equals(dtos.get(0).getMem_pwd())) {
//				return res=1;
//			} else {
//				return res=1;
//			}
//		}
//		
//		log.info("@# login end");
//	}
//	
//	@ResponseBody
//	@RequestMapping(value="/api/reqMem")
//	public String login(@RequestParam HashMap<String, String> param) {
//		log.info("@# login");
//		ArrayList<TempDto> dtos = TempService.login(param);
//		
//		if (dtos.isEmpty()) {
//			return res=1;
//		} else {
//			if (param.get("mem_pwd").equals(dtos.get(0).getMem_pwd())) {
//				return res=1;
//			} else {
//				return res=1;
//			}
//		}
//	}
	
}
