package com.lgy.spring_react_server.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TempDto {
	private String uid;
	private String pwd;
	private String email;
	private String name;
	private String birthday;
	private String address1;
	private String address2;
}
